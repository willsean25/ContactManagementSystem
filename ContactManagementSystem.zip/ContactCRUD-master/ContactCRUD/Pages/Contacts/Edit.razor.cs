﻿using Blazored.Toast.Services;
using ContactCRUD.Data.Entities;
using ContactCRUD.Services.Interface;
using Microsoft.AspNetCore.Components;

namespace ContactCRUD.Pages.Contacts
{
    public partial class Edit
    {
        [Inject]
        public IContactService _contactService { get; set; }

        [Inject]
        public NavigationManager _navigationManager { get; set; }

        [Inject]
        public IToastService _toastService { get; set; }

        [Parameter]
        public string Id { get; set; } = default;
        public Contact ContactDTO { get; set; } = new Contact();
        private bool _showModal = false;
        protected override async Task OnInitializedAsync()
        {
            if (string.IsNullOrEmpty(Id))
            {
                ContactDTO = new Contact();
                ContactDTO.BirthDate = DateTime.Now;
            }
            else
            {
                // if an ID is passed, we are getting the contact with that ID
                // gets the current contact values
                ContactDTO = await _contactService.GetContactByIdAsync(new Guid(Id));
            }
        }

        public async Task HandleValidSubmit()
        {
            // If Id is not null just update the entity
            
            if(ContactDTO.Id != null)
            {
                await this._contactService.UpdateContactAsync(ContactDTO);
            }
            // If Id is null add new entity
            else
            {
                await this._contactService.SaveContactAsync(ContactDTO);
            }
             // display message
            _toastService.ShowSuccess("Successfully saved!");
            // return to our list page
            _navigationManager.NavigateTo("/Contacts/List");
        }
        void ShowModal()
        {
            _showModal = true;
        }
        void CloseModal()
        {
            _showModal = false;
        }

        async void onDelete()
        {
            await _contactService.DeleteContactAsync(ContactDTO);

            _toastService.ShowSuccess("Successfully Delete!");

            _navigationManager.NavigateTo("/Contacts/List");
        }
    }
}
