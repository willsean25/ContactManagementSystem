﻿using ContactCRUD.Data.Entities;
using ContactCRUD.Services.Interface;
using Microsoft.AspNetCore.Components;

namespace ContactCRUD.Pages.Contacts
{
    public partial class List
    {
        [Inject]
        public IContactService _contactService { get; set; }
        public List<Contact>? Contacts { get; set; } = default;
        public string sortedBy { get; set; } = "";


        protected override async Task OnInitializedAsync()
        {
            // Gets all of the contacts from the database when the page is initialized
            Contacts = await _contactService.GetAllContactsAsync();
        }

        public async Task OnSortLastName()
        {
            // when we sort by last name, get the contacts by last name ascending
            sortedBy = "LastName";
            Contacts = await _contactService.GetAllContactsAsync("LastName","Asc");
        }
        public async Task OnSortFirstName()
        {
            // when we sort by first name, get the contacts by first name ascending
            sortedBy = "FirstName";
            Contacts = await _contactService.GetAllContactsAsync("FirstName", "Asc");
        }

    }
}
