﻿using ContactCRUD.Data;
using ContactCRUD.Data.Entities;
using ContactCRUD.Services.Interface;
using Microsoft.EntityFrameworkCore;

namespace ContactCRUD.Services
{
    public class ContactService : IContactService
    {    
        private readonly AppDbContext _context;
        public ContactService(AppDbContext context)
        {
            this._context = context;
        }
        public async Task DeleteContactAsync(Contact contact)
        {
            // this function removes a contact from the list then saves the list
            _context.Contacts.Remove(contact);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Contact>> GetAllContactsAsync(string sortByColumnName = "", string sortBy = "")
        {
            var contacts = new List<Contact>();
            // if we are going to sort
            if (!string.IsNullOrEmpty(sortByColumnName) && !string.IsNullOrEmpty(sortBy))
            {
                if (sortByColumnName == "FirstName")
                {
                    // when we sort by the first name, we sort by ascending values
                    if(sortBy == "Asc")
                    {
                        contacts = await _context.Contacts.OrderBy(x=> x.FirstName).ThenBy(x => x.LastName).ToListAsync();
                    }
                    else
                    {
                        contacts = await _context.Contacts.OrderByDescending(x => x.FirstName).ThenBy(x => x.LastName).ToListAsync();
                    }
                }
                else if(sortByColumnName == "LastName")
                {
                    // when we sort by the last name, we sort by ascending values
                    if (sortBy == "Asc")
                    {
                        contacts = await _context.Contacts.OrderBy(x => x.LastName).ThenBy(x => x.FirstName).ToListAsync();
                    }
                    else
                    {
                        contacts = await _context.Contacts.OrderByDescending(x => x.LastName).ThenBy(x => x.FirstName).ToListAsync();
                    }
                }
            }
            // if we are not going to sort
            else
            {
                contacts = await _context.Contacts.ToListAsync();
            }

            return contacts;
        }

        public async Task<Contact> GetContactByIdAsync(Guid id)
        {
            // returning a certain contact by its ID
            return await _context.Contacts.FindAsync(id);
        }

        public async Task SaveContactAsync(Contact contact)
        {
            // adding a contact to our Contacts list
            this._context.Contacts.Add(contact);
            await this._context.SaveChangesAsync();
        }

        public async Task UpdateContactAsync(Contact contact)
        {
            // updating an existing contact in the contacts list 
            this._context.Contacts.Update(contact);
            await this._context.SaveChangesAsync();
        }
    }
}
