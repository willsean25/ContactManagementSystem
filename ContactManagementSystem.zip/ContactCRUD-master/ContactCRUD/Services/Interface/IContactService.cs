﻿using ContactCRUD.Data.Entities;

namespace ContactCRUD.Services.Interface
{
    public interface IContactService
    {
        Task SaveContactAsync(Contact contact);
        Task UpdateContactAsync(Contact contact);
        Task DeleteContactAsync(Contact contact);
        Task<List<Contact>> GetAllContactsAsync(string sortByColumnName = "", string sortBy = "");
        Task<Contact> GetContactByIdAsync(Guid id);
    }
}
