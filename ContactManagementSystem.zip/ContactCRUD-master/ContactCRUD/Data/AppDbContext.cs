﻿using ContactCRUD.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

// included the contact class in here to create a dbSet of contactc
namespace ContactCRUD.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        // creating the set of contacts, created automatically as tables using EF
        public DbSet<Contact> Contacts { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}
