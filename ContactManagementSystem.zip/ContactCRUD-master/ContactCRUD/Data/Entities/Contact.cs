﻿using System.ComponentModel.DataAnnotations;

namespace ContactCRUD.Data.Entities
{
    public class Contact
    {
        public Guid Id { get; set; }

        [Required]
        [StringLength(250)]
        [Display(Name ="Last Name")]
        public string LastName { get; set; }

        [Required]
        [StringLength(250)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [StringLength(15)]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Birth Date")]
        public DateTime BirthDate { get; set; }
    }
}
